package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="contact_details")
public class ContactDetails {

	/*Primary key tagged with GeneratedValue IDENTITY so that 
	 * when a new Contact is created, the User does not need to
	 * create the ID for the object in the database*/
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="contact_id", length=10)
	private long contact_id;
	@Column(name="contact_name", length=50)
	private String contact_name;
	@Column(name="contact_email", length=50)
	private String contact_email;
	@Column(name="contact_number", length=10)
	private long contact_number;
	
	//Getters and setters
	public long getContact_id() {
		return contact_id;
	}
	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}
	public String getContact_name() {
		return contact_name;
	}
	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}
	public String getContact_email() {
		return contact_email;
	}
	public void setContact_email(String contact_email) {
		this.contact_email = contact_email;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
	
	//Overloaded constructor - all fields
	public ContactDetails(long contact_id, String contact_name, String contact_email, long contact_number) {
		super();
		this.contact_id = contact_id;
		this.contact_name = contact_name;
		this.contact_email = contact_email;
		this.contact_number = contact_number;
	}
	
	//Default constructor
	public ContactDetails() {
		super();
	}
	
	@Override
	public String toString() {
		return "ContactDetails [contact_id=" + contact_id + ", contact_name=" + contact_name + ", contact_email="
				+ contact_email + ", contact_number=" + contact_number + "]";
	}
	
	
}
