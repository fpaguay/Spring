package com.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.ContactDetails;
import com.repository.ContactDetailsRepository;

@Service
public class ContactDetailsService {

	@Autowired
	ContactDetailsRepository repository;
	
	/*CRUD OPERATIONS*/
	
	//Create Contact Details
	public void addContact(ContactDetails contact) {
		repository.save(contact);
	}
	
	//Read Contact
	public ContactDetails getContact(long contact_id) {
		
		ContactDetails returnContact = null;
		
		Optional<ContactDetails> opt = repository.findById(contact_id);
		
		if (opt.isPresent()) {
			returnContact = opt.get();
			return returnContact;
		}
		
		//returns null if contact could not be found
		return returnContact;
	}
	
	//Read All Contacts
	public ArrayList<ContactDetails> getAllContacts() {
		
		ArrayList<ContactDetails> returnContactList = (ArrayList<ContactDetails>) repository.findAll();
		
		return returnContactList;
	}
	
	//Update Contact
	public void updateContact(long contact_id, String contact_name, String contact_email, long contact_number) {
		
		ContactDetails updateContact = new ContactDetails();;
		
		Optional<ContactDetails> opt = repository.findById(contact_id);
		
		if (opt.isPresent()) {
			updateContact.setContact_id(contact_id);
			updateContact.setContact_name(contact_name);
			updateContact.setContact_email(contact_email);
			updateContact.setContact_number(contact_number);
			
			//as long as the contact_id is the same as a value already present in the table
			// CRUDRepository is able to update access automatically
			repository.save(updateContact);
		}
	}
	
	//Delete Contact
	public void deleteContact(long contact_id) {
		repository.deleteById(contact_id);
	}
	
	
	
	/*toSting implementations, leftover from a previous version of the project*/
	
	//Read Contact
	public String getContact_toString(long contact_id) {
		
		ContactDetails returnContact = new ContactDetails();
		
		Optional<ContactDetails> opt = repository.findById(contact_id);
		
		if (opt.isPresent()) {
			returnContact = opt.get();
			return returnContact.toString();
		}
		
		//returns null if contact could not be found
		return returnContact.toString();
	}
	
}
