package com.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.ContactDetails;
import com.service.ContactDetailsService;

@RestController
public class ContactDetailsController {

	@Autowired
	private ContactDetailsService service;
	
	/*HTTP Request Mappings for REST API*/
	
	//HTTP GET Mappings
	@GetMapping("/getContact/{contact_id}")
	public ContactDetails getContact(@PathVariable("contact_id")long contact_id) {
		//gets the ContactDetails object, when called by Consumer, the return is formatted in JSON
		ContactDetails fetchedContact = service.getContact(contact_id);
		
		return fetchedContact;
	}
	
	
	@GetMapping("/getAllContacts")
	public ArrayList<ContactDetails> getAllContacts() {
		
		ArrayList<ContactDetails> fetchedContactList = service.getAllContacts();
		
		return fetchedContactList;
	}
	
	//HTTP POST Mapping
	@PostMapping("/updateContact/{contact_id}/{contact_name}/{contact_email}/{contact_number}")
	public void updateContact(@PathVariable("contact_id")long contact_id, @PathVariable("contact_name")String contact_name, @PathVariable("contact_email")String contact_email, @PathVariable("contact_number")long contact_number) {
		//collects all values from the Consumer POST call, then updates
		service.updateContact(contact_id, contact_name, contact_email, contact_number);
	}
	
		
	@PostMapping("/deleteContact/{contact_id}") 
	public void deleteContact(@PathVariable("contact_id")long contact_id) {
		//collects Contact ID from Consumer call
		service.deleteContact(contact_id);
	}
	
	@PostMapping("/addContact/{contact_name}/{contact_email}/{contact_number}")
	public void addContact(@PathVariable("contact_name") String contact_name, @PathVariable("contact_email") String contact_email, @PathVariable("contact_number") long contact_number) {
		
		ContactDetails contactToAdd = new ContactDetails();
		
		//set incoming values
		//Contact ID is auto-created within the ContactDetails entity class
		contactToAdd.setContact_name(contact_name);
		contactToAdd.setContact_email(contact_email);
		contactToAdd.setContact_number(contact_number);
		
		service.addContact(contactToAdd);
	}
	
}
