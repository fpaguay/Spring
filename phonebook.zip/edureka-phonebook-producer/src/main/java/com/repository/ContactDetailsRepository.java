package com.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.ContactDetails;

@Repository
public interface ContactDetailsRepository extends CrudRepository<ContactDetails, Long> {

	//Entity tied to ContactDetails, Long Wrapper datatype tied to Primary Key
}
