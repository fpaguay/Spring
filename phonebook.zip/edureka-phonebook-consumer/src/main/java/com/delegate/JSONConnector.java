package com.delegate;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.ContactDetailsCopy;

public class JSONConnector {
		
	//JSON connector class acts to read the RestTemplate class results and
	//parse JSON into the necessary objects for the consumer
	
	private ObjectMapper mapper = new ObjectMapper();
	
	//Intakes the delegate call for RestTemplate results, outputs the array to be used for populating UI
	public ArrayList<ContactDetailsCopy> fromJSON_getAllContacts(ContactDelegate delegate) throws JsonMappingException, JsonProcessingException {
		
		//configure Jackson to treat Integer values as a LONG value
		mapper.configure(DeserializationFeature.USE_LONG_FOR_INTS, true);
		
		//get the RestTemplate list result and convert it into ArrayList of ContactDetails
		ArrayList<ContactDetailsCopy> testJSONList = mapper.readValue(delegate.connectGetAllContacts(), new TypeReference<ArrayList<ContactDetailsCopy>>() {});
		
		return testJSONList;
	}
	
	//Intakes the delegate call for RestTemplate results, outputs one reference to Contact Details
	public ContactDetailsCopy fromJSON_getContact(long contact_id, ContactDelegate delegate) throws JsonMappingException, JsonProcessingException {
		
		//configure Jackson to treat Integer values as a LONG value
		mapper.configure(DeserializationFeature.USE_LONG_FOR_INTS, true);
		
		ContactDetailsCopy testJSONObject = mapper.readValue(delegate.connectGetContact(contact_id), new TypeReference<ContactDetailsCopy>() {});
		
		return testJSONObject;
		
	}

}


