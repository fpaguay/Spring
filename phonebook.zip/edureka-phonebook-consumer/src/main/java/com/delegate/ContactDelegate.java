package com.delegate;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.model.ContactDetailsCopy;

@Service
public class ContactDelegate {

	//Delegate class connects the requests onto the Producer Server for REST API calls
	//All RestTemplate calls return a JSON String, which is formatted by JSONConnector class
	private final RestTemplate template;
	
	public ContactDelegate(RestTemplateBuilder restTemplateBuilder) {
		this.template = restTemplateBuilder.build();
	}
	
	//URL calls for data collection 
	private String URL_getContact = "http://localhost:9000/getContact/{contact_id}";
	private String URL_getAllContact = "http://localhost:9000/getAllContacts";
	private String URL_deleteContact = "http://localhost:9000/deleteContact/{contact_id}";
	private String URL_addContact = "http://localhost:9000/addContact/{contact_name}/{contact_email}/{contact_number}";
	private String URL_editContact = "http://localhost:9000/updateContact/{contact_id}/{contact_name}/{contact_email}/{contact_number}";
	
	/*RESTful API Calls*/
	
	//HTTP GET calls
	public String connectGetContact(@PathVariable("contact_id")long contact_id) {
		
		String resource = this.template.exchange(URL_getContact, HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}, contact_id).getBody();
		
		return resource;
	}
	
	public String connectGetAllContacts() {
		
		String resource = this.template.exchange(URL_getAllContact, HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}).getBody();
		
		return resource;
	}
	
	//HTTP POST calls
	public String connectDeleteContact(@PathVariable("contact_id")long contact_id) {
	
		String resource = this.template.exchange(URL_deleteContact, HttpMethod.POST, null, new ParameterizedTypeReference<String>() {}, contact_id).getBody();
		
		return resource;
	}
	
	public String connectAddContact(@PathVariable("contact_name") String contact_name, @PathVariable("contact_email") String contact_email, @PathVariable("contact_number") long contact_number) {
		
		String resource = this.template.exchange(URL_addContact, HttpMethod.POST, null, new ParameterizedTypeReference<String>() {}, contact_name, contact_email, contact_number).getBody();
		
		return resource;
	}
	
	public String connectEditContact(@PathVariable("contact_id") long contact_id, @PathVariable("contact_name") String contact_name, @PathVariable("contact_email") String contact_email, @PathVariable("contact_number") long contact_number) {
		String resource = this.template.exchange(URL_editContact, HttpMethod.POST, null, new ParameterizedTypeReference<String>() {}, contact_id, contact_name, contact_email, contact_number).getBody();
		
		return resource;
	}
		
	/*
	 * //JSON Collector public ArrayList<ContactDetailsCopy>
	 * connectGetContacts_fromJSON() {
	 * 
	 * ResponseEntity<ArrayList<ContactDetailsCopy>> entity =
	 * template.exchange(URL_getAllContact, HttpMethod.GET, null, new
	 * ParameterizedTypeReference<ArrayList<ContactDetailsCopy>>() {});
	 * 
	 * ArrayList<ContactDetailsCopy> returnList = entity.getBody();
	 * 
	 * System.out.println(returnList.get(0).getContact_name());
	 * 
	 * return null;
	 * //returnList.stream().map(ContactDetailsCopy::getContact_id).collect(
	 * Collectors.toList()); }
	 */
}
