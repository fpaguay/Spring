package com.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContactDetailsCopy {

	/*ContactDetailsCopy class has been created to store the REST API calls from 
	 * the producer server. The data is first collected as JSON from the RestTemplate
	 * API calls, then the values within JSON are populated into the class
	 * */

	@JsonProperty("contact_id")
	private long contact_id;
	@JsonProperty("contact_name")
	private String contact_name;
	@JsonProperty("contact_email")
	private String contact_email;
	@JsonProperty("contact_number")
	private long contact_number;
		
	//Getters and setters
	public long getContact_id() {
		return contact_id;
	}
	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}
	public String getContact_name() {
		return contact_name;
	}
	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}
	public String getContact_email() {
		return contact_email;
	}
	public void setContact_email(String contact_email) {
		this.contact_email = contact_email;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
		
	//Overloaded constructor - all fields
	public ContactDetailsCopy(long contact_id, String contact_name, String contact_email, long contact_number) {
		super();
		this.contact_id = contact_id;
		this.contact_name = contact_name;
		this.contact_email = contact_email;
		this.contact_number = contact_number;
	}
	
	//Default constructor
	public ContactDetailsCopy() {
		super();
	}

}
