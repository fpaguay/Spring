package com.phonebook.edurekaphonebookconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class EdurekaPhonebookConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdurekaPhonebookConsumerApplication.class, args);
	}

}
