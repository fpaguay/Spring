package com.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.delegate.ContactDelegate;
import com.delegate.JSONConnector;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.model.ContactDetailsCopy;

@Controller
public class PageController {
		
	//Delegate for RestTemplate
	@Autowired
	private ContactDelegate delegate;

	//Arraylist for UI results
	ArrayList<ContactDetailsCopy> contactList = new ArrayList<ContactDetailsCopy>();
	
	//JSONConnector for formatting API responses
	JSONConnector jsonConnector = new JSONConnector();
		
	/*JSP Page directions*/
	
	//HTML GET Mappings
	//viewContact.jsp
	
	//routes to AddContact page when localhost:9050 is called directly
	@RequestMapping("/")
	public String index() {
		return "redirect:/addContact";
	}
	
	@GetMapping("/phonebook")
	public String phonebook(Model model) throws JsonMappingException, JsonProcessingException{
		
		//get all contacts in the server database, process the JSON output, and make it into a list for our UI
		contactList = jsonConnector.fromJSON_getAllContacts(delegate);
		model.addAttribute("contactList", contactList);
		
		return "viewContact";
	}
	
	//contact.jsp
	@GetMapping("/addContact")
	public String home() {
		return "contact";
	}
	
	//editContact.jsp
	@GetMapping("/editContact/{contact_id}")
	public String editContact(@PathVariable long contact_id, Model model) throws JsonMappingException, JsonProcessingException {
		
		ContactDetailsCopy editContact = jsonConnector.fromJSON_getContact(contact_id, delegate);
		
		model.addAttribute("editContact", editContact);
		
		return "editContact";
	}
	
	//deleteContact.jsp
	@GetMapping("/deleteContact/{contact_id}")
	public String deleteContact(@PathVariable long contact_id, Model model) throws JsonMappingException, JsonProcessingException {
		
		ContactDetailsCopy deleteContact = jsonConnector.fromJSON_getContact(contact_id, delegate);
		
		model.addAttribute("deleteContact", deleteContact);
		
		return "deleteContact";
	}	
	
	//HTTP POST Mapping
	@PostMapping("/deleteContact/{contact_id}")
	public String deleteContact_afterConfirm(@PathVariable long contact_id) {
		
		delegate.connectDeleteContact(contact_id);
		
		//back to Phonebook
		return "redirect:/phonebook";	
	}
	
	@PostMapping("/editContact/{contact_id}")
	public String editContact_afterConfirm(@RequestParam("contactID") long contact_id, @RequestParam("contactName") String contact_name, @RequestParam("contactNumber") long contact_number, @RequestParam("contactEmail") String contact_email) throws JsonMappingException, JsonProcessingException {
				
		delegate.connectEditContact(contact_id, contact_name, contact_email, contact_number);
			
		//delegate.connectDeleteContact(contact_id);
		//return to phonebook
		return "redirect:/phonebook";
	}
	
	@PostMapping("/addContact")
	public String saveContact_afterConfirm(@RequestParam("contactName") String contact_name, @RequestParam("contactEmail") String contact_email, @RequestParam("contactNumber") long contact_number) {
		
		delegate.connectAddContact(contact_name, contact_email, contact_number);
		
		return "redirect:/phonebook";
	}
	
}
