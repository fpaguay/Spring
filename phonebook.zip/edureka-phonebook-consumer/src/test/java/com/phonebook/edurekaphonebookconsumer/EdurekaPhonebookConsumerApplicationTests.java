package com.phonebook.edurekaphonebookconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdurekaPhonebookConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
