Spring Case Study- Phonebook

A simple application to emulate a phonebook, allows User to access contact details and perform CRUD operations as needed
------------------------------------------------------------------------------------------------------------------------------------------------------------
Technologies in Use

- Spring Boot 2.6.7 (Producer), Spring Boot 2.5.13 (Consumer)
- Java 8
- JDK 1.8
- H2 Database
- JSP Pages
- Bootstrap CSS
------------------------------------------------------------------------------------------------------------------------------------------------------------

Microservice list
 
* edureka-phonebook-producer: stores contact information in database, and accepts REST API calls for CRUD operations on contacts
* edureka-phonebook-consumer: displays UI for user through JSPs, calls the producer microservice for CRUD operations on contacts
------------------------------------------------------------------------------------------------------------------------------------------------------------

App Navigation 

1) Phonebook Consumer (localhost:9050)
	- URL format is tied to the functions they serve
	- {contact_id}: the contact's ID in the database
	- sample URL calls
		HTTP GET calls
		- view add contact/landing page
			http://localhost:9050 OR http://localhost:9050/addContact
		- view phonebook
			http://localhost:9050/phonebook
		- view edit for contact
			http://localhost:8200/editContact/{contact_id}
		- view delete for contact
			http://localhost:8060/deleteContact/{contact_id}

		*POST calls and operations are tied to the page responses

2) Phonebook Producer (localhost:9000)
	- URL format is tied to CRUD operations to server in GET and POST calls from Consumer
	- {contact_id}: the contact's ID in the database
	- {contact_name}: the contact's name
	- {contact_number}: the contact's phone number
	- {contact-email}: the contact's email address
	- sample URL calls(*+ NOTES below):
		HTTP GET calls
		- get a contact object from database
			http://localhost:9000/getContact/{contact_id}
		- get all contacts from database
			http://localhost:9000/getAllContacts
		HTTP POST calls
		- add a contact object to database
			http://localhost:9000/addContact/{contact_name}/{contact_email}/{contact_number}
		- update a contact object in database
			http://localhost:9000/updateContact/{contact_id}
		- delete a contact object from database
			http://localhost:9000//deleteContact/{contact_name}/{contact_email}/{contact_number}

	*NOTE: these calls are intended only for communication between Producer and Consumer. Accessing them directly will not function unless
	the user knows how the app is formatted.

	+NOTE: the contact objects collected from the database in the Producer microservice are returned as JSON objects, then converted to appropriate
	 objects on the Consumer app.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Running Program

- Upon importing files onto a development application, run the SpringBootApplication classes for Producer and Consumer
- Once the programs are running, access the app by calling with browser
	http://localhost:9050
------------------------------------------------------------------------------------------------------------------------------------------------------------

Data Operations 

The producer microservice stores data using the H2 in-memory database. Please note this version of the project does not store on SQL file,
hence stopping the producer microservice will also clear the user data

------------------------------------------------------------------------------------------------------------------------------------------------------------